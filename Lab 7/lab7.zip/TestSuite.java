import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	addTest.class,
	delTest.class
})

public class TestSuite {}
